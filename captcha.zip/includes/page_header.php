<?php

if (!defined('ROOT_PATH')) {
  die("Security violation");
}

echo "<h1> header </h1>";
?>