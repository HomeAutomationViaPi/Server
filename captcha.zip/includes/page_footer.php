<?php

if (!defined('ROOT_PATH')) {
  die("Security violation");
}

echo "<h1> Footer <h2>";
?>